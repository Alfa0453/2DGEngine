#pragma once

#include "SpriteRegion.h"

namespace Engine
{
    struct AnimationFrame2D
    {
        SpriteRegion Region;

        AnimationFrame2D() = default;

        explicit AnimationFrame2D(const SpriteRegion& region)
            : Region(region)
        {
        }
    };
}