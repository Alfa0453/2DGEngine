#pragma once

#include "../Graphics/AnimationClip2D.h"
#include "Component.h"

#include <cstddef>

namespace Engine
{
    class SpriteRendererComponent;

    class AnimatorComponent : public Component
    {
    public:
        AnimatorComponent() = default;

        void Start() override;

        void Update(float deltaTime) override;

        void Play(const AnimationClip2D* clip, bool restartIfSame = false);

        void Pause();

        void Resume();

        void Stop();

        bool IsPlaying() const;

        bool IsPaused() const;

        const AnimationClip2D* GetCurrentClip() const;

        std::size_t GetCurrentFrameIndex() const;

        float GetPlaybackTime() const;

        void SetPlaybackSpeed(float speed);

        float GetPlaybackSpeed() const;

    private:
        void ApplyCurrentFrame();

        void AdvanceFrame();

    private:
        SpriteRendererComponent* m_SpriteRenderer = nullptr;

        const AnimationClip2D* m_CurrentClip = nullptr;

        std::size_t m_CurrentFrameIndex = 0;

        float m_FrameTimer = 0.0f;

        float m_PlaybackTime = 0.0f;

        float m_PlaybackSpeed = 1.0f;

        bool m_IsPlaying = false;

        bool m_IsPaused = false;
    };
}