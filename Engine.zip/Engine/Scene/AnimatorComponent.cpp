#include "AnimatorComponent.h"
#include "Entity.h"
#include "SpriteRendererComponent.h"

namespace Engine
{
    void AnimatorComponent::Start()
    {
        Entity* owner = GetOwner();

        if (!owner)
        {
            return;
        }

        m_SpriteRenderer = owner->GetComponent<SpriteRendererComponent>();

        if (m_CurrentClip && m_CurrentClip->IsValid())
        {
            ApplyCurrentFrame();
        }
    }

    void AnimatorComponent::Play(const AnimationClip2D* clip, bool restartIfSame)
    {
        if (!clip || !clip->IsValid())
        {
            Stop();
            return;
        }

        if (m_CurrentClip == clip && m_IsPlaying && !restartIfSame)
        {
            return;
        }

        m_CurrentClip = clip;

        m_CurrentFrameIndex = 0;

        m_FrameTimer = 0.0f;

        m_PlaybackTime = 0.0f;

        m_IsPlaying = true;

        m_IsPaused = false;

        ApplyCurrentFrame();
    }

    void AnimatorComponent::ApplyCurrentFrame()
    {
        if (!m_SpriteRenderer || !m_CurrentClip)
        {
            return;
        }

        const AnimationFrame2D* frame = m_CurrentClip->GetFrame(m_CurrentFrameIndex);

        if (!frame)
        {
            return;
        }

        m_SpriteRenderer->SetSpriteRegion(frame->Region);
    }

    void AnimatorComponent::AdvanceFrame()
    {
        if (!m_CurrentClip || m_CurrentClip->GetFrameCount() == 0)
        {
            Stop();
            return;
        }

        ++m_CurrentFrameIndex;

        if (m_CurrentFrameIndex >= m_CurrentClip->GetFrameCount())
        {
            if (m_CurrentClip->IsLooping())
            {
                m_CurrentFrameIndex = 0;
            }
            else 
            {
                m_CurrentFrameIndex = m_CurrentClip->GetFrameCount() - 1;

                m_IsPlaying = false;

                m_IsPaused = false;
            }
        }

        ApplyCurrentFrame();
    }

    void AnimatorComponent::Update(float deltaTime)
    {
        if (!m_IsPlaying || m_IsPaused || !m_CurrentClip || !m_CurrentClip->IsValid())
        {
            return;
        }

        if (m_PlaybackSpeed <= 0.0f)
        {
            return;
        }

        const float scaledDelta = deltaTime * m_PlaybackSpeed;

        m_FrameTimer += scaledDelta;

        m_PlaybackTime += scaledDelta;

        const float frameDuration = m_CurrentClip->GetFrameDuration();

        while (m_FrameTimer >= frameDuration && m_IsPlaying)
        {
            m_FrameTimer -= frameDuration;

            AdvanceFrame();
        }
    }

    void AnimatorComponent::Pause()
    {
        if (m_IsPlaying)
        {
            m_IsPaused = true;
        }
    }

    void AnimatorComponent::Resume()
    {
        if (m_IsPlaying)
        {
            m_IsPaused = false;
        }
    }

    void AnimatorComponent::Stop()
    {
        m_CurrentClip = nullptr;

        m_CurrentFrameIndex = 0;

        m_FrameTimer = 0.0f;

        m_PlaybackTime = 0.0f;

        m_IsPlaying = false;

        m_IsPaused = false;
    }

    void AnimatorComponent::SetPlaybackSpeed(float speed)
    {
        m_PlaybackSpeed = speed >= 0.0f ? speed : 0.0f;
    }

    float AnimatorComponent::GetPlaybackSpeed() const
    {
        return  m_PlaybackSpeed;;
    }

    bool AnimatorComponent::IsPlaying() const
    {
        return m_IsPlaying;
    }

    bool AnimatorComponent::IsPaused() const
    {
        return m_IsPaused;
    }

    const AnimationClip2D* AnimatorComponent::GetCurrentClip() const
    {
        return m_CurrentClip;
    }

    std::size_t AnimatorComponent::GetCurrentFrameIndex() const
    {
        return m_CurrentFrameIndex;
    }

    float AnimatorComponent::GetPlaybackTime() const
    {
        return m_PlaybackTime;
    }
}